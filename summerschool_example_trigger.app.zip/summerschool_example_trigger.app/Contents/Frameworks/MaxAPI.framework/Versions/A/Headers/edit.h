/*************************/
/* Copyright 1988 IRCAM. */
/*************************/

#ifndef _EDIT_H_
#define _EDIT_H_

// 	NOTE: This file is obsolete.

#endif /* _EDIT_H_ */
